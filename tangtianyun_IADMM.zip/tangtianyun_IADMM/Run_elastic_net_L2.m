%% Elastic net regularized regression with L2 loss function
% min ||y||_2 +mu_1||z||_1+mu2/2||z||^2
%  s.t . y-Bz = -c.
%%
clc;
clear all;
close all;
addpath('Solver');
addpath('Operator/L2/');
rand('seed',20200420); randn('seed',20200420);
useADMM = 1;
P = [300,1000,5000];
N = [100,200,1750];
S = [30,50,500];
idx1 = 1:3; % data size
idx2 = 1:3; % type of ADMM
idx3 = -5:0.25:5; % initial beta
L2_tra_hist = [];
L2_ada_hist = [];
L2_ba_hist = [];
for i1 = idx1
    %% generated data
    p = P(i1);
    n = N(i1);
    s = S(i1);
    B = randn(n, p)/sqrt(n);
    B_norm = norm(B);
    z = zeros(p, 1);
    T = randsample(n, s);
    z(T) = randn(s, 1);
    noise = randn(n, 1);
    mu1 = 1e-2;
    mu2 = 1e-1;
    sigma = 1e-3; % choose : 0 or 1e-3
    c = B*z+sigma*noise;
    for j1 = idx2
        for k1 = idx3
            %% parameter for ADMM
            param.C = @(z)-B*z;
            param.CT = @(y)-B'*y;
            param.Q = @(z) B_norm^2*z-B'*(B*z);
            param.b = -c;
            if j1 == 1
                param.acc = 'Tra';
            elseif j1 == 2
                param.acc = 'Ada';
            elseif j1 == 3
                param.acc = 'Ba';
            end
            fprintf('\n ************************************************\n');
            fprintf('\n test: ADMM %s, n = %2d, p = %2d, s = %2d, beta = %3.2e',param.acc,n,p,s,10^k1);
            param.lam0 = zeros(n,1);
            param.z0 = zeros(p,1);
            param.y0 = -c;
            param.beta = 10^k1;
            param.betamin = 1e-6;
            param.tau = 1.5;
            param.sig = mu2;
            param.Cnorm = B_norm;
            param.Maxiter = 1000;
            param.Maxtime = 300;
            param.tol = 1e-5;
            param.verbose = 0;
            param.restart = 0; % restart frequency, 0: no restart.
            %% operator for elastic regression
            Update_f = @(z,lam,beta)L2_f(B,c,z,lam,beta);
            Update_g = @(y,z,lam,beta)L2_g(mu1,mu2,B_norm,B,c,y,z,lam,beta);
            KT_resp = @(y,z)L2_resp(c,B,y,z);
            KT_resd = @(y,z,lam)L2_resd(mu1,mu2,B,y,z,lam);
            %% ADMM
            if useADMM == 1
                [runhist,Time] = ADMM_Solver(Update_f,Update_g,KT_resp,KT_resd,param);
                iter = runhist.iter;
                Resp = runhist.Resp;
                Resd = runhist.Resd;
                resp = Resp(end);
                resd = Resd(end);
                fprintf('\n iter = %2d, resp = %3.2e, resd = %3.2e',iter,resp,resd);
                if j1 == 1
                    L2_tra_hist = [L2_tra_hist,runhist];
                elseif j1 == 2
                    L2_ada_hist = [L2_ada_hist,runhist];
                elseif j1 == 3
                    L2_ba_hist = [L2_ba_hist,runhist];
                end
                
            end
        end
    end
end
%% plot results
S_ada = L2_ada_hist;
S_tra = L2_tra_hist;
S_ba = L2_ba_hist;
S_ada_iter = [S_ada.iter];
S_tra_iter = [S_tra.iter];
S_ba_iter = [S_ba.iter];
Beta = 10.^(idx3);
l = length(S_ada_iter)/3;
for i = 1:3
    subplot(1,3,i)
    loglog(Beta,S_ada_iter((i-1)*l+1:i*l),'g-','linewidth',1);
    hold on
    loglog(Beta,S_tra_iter((i-1)*l+1:i*l),'k--','linewidth',1);
    loglog(Beta,S_ba_iter((i-1)*l+1:i*l),'r+','linewidth',1);
    legend('IADMM','ADMM','Heu-ADMM');
    title(['L2: p=', num2str(P(i)),',n=', num2str(N(i)),',s=',num2str(S(i))]);
    ylim([10,10^3.2]);
    set(gca,'YTick',[10,10^2,10^3]);
    set(gca,'YTicklabel',{'10','10^2','10^3'});
    set(gca,'fontsize',12);
    xlabel('Initial penalty','fontsize',12);
    ylabel('Iterations','fontsize',12);
end
save('L2_result.mat','L2_tra_hist','L2_ada_hist','L2_ba_hist');








