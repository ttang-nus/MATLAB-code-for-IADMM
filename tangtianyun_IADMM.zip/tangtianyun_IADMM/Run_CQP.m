%% Convex quadratic programming  
%% min xTQx/2+cTx s.t. Ax=b, lb<=x<=ub 
%% min zTQz/2+cTz+delta_{[lb,ub]}(z)+delta_{[Ay-b=0]}(y) s.t. y=z 
%% this problem is to verify the theory  
close all;  
clear all; 
addpath('Solver');  
addpath('Operator/CQP/'); 
%addpath('/opt/gurobi952/linux64/matlab/'); 
%addpath(fullfile('/opt/gurobi952/linux64/examples/matlab/'));  
%addpath('/home/tang/Documents/MATLAB/Dataset/QP-Test-Problems-master/MAT_Files/');  
addpath('datademo/');
fname = {'CVXQP3_L','HUES-MOD','HUESTIS'}; 
%% load data 
tol = 1e-5;
dfname = []; 
datatype = 2; 
for k = 3
    rng('default'); 
    load([fname{k},'.mat']); 
    b = rl; 
    nn = size(Q,1); 
    if nn > 20000 
        error('\n too many variables'); 
    end 
    if isdiag(Q)
        B = randn(nn,nn);
        BB = B*B';
        BB = BB/norm(BB,'fro');
        Q = Q+1e-6*norm(Q,'fro')*BB;
    end
    if k >= 14
        Q1 = A*A';
        [L,D,p] = ldl(Q1,'vector');
        d = diag(D);
        idx = p(find(d>1e-12));
        A = A(idx,:);
        b = b(idx,:);
    end
    AT = A';
    [m,n] = size(A);
    beta = eigs(Q,1,'largestreal');
    verbose = 1;
    %% IADMM
    param.beta = beta;
    param.tol = tol;
    param.verbose = verbose;
    param.Maxiter = 100;
    param.Maxtime = 3600;
    [runhist] = PPPA_CQP(Q,c,A,b,lb,ub,param); 
    z = runhist.z;
    y = runhist.y; 
    iter = runhist.iter;
    ttime = runhist.ttime;
    KTp = runhist.KTp;
    KTd = runhist.KTd;
    fval = runhist.fval;
    fprintf('\n %s & PPPM & %3.2e & %3.2e & %6.7e& %3.2e \\\\',fname{k},KTp,KTd,fval,ttime);
    fprintf('\n \\hline \\\\')
end






