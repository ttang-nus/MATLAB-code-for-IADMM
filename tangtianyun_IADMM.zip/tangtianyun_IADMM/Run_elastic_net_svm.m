%% Elastic net regularized SVM
% min 1/m*e^T[y]_+ +mu_1||z||_1+mu2/2||z||^2
%  s.t . y+Bz=e.
%%
clc;
clear all;
close all;
addpath('Solver');
addpath('Operator/SVM/');
rand('seed',20200420); randn('seed',20200420);
useADMM = 1;
P = [50,500,2000];
M = [500,100,200];
S = [10,50,100];
idx1 = 1:3; % data size
idx2 = 1:3; % type of ADMM
idx3 = -5:0.25:5; % initial beta
SVM_tra_hist = [];
SVM_ada_hist = [];
SVM_ba_hist = [];
for i1 = idx1
    %% generated data
    p = P(i1);
    m = M(i1);
    s = S(i1);
    rho = 0.5;
    mean_vec = [ones(s,1); zeros(p-s,1)];
    [V,D] = eig((1-rho)*eye(s)+rho*ones(s));
    d = diag(D);
    cov_mat = [V*diag(sqrt(d)), zeros(s,p-s); zeros(p-s,s), eye(p-s)];
    A = zeros(p,m);
    b = zeros(m,1);
    for i = 1:m/2
        b(i) = 1;
        A(:,i) = cov_mat*randn(p,1) + mean_vec;
        A(:,i) = A(:,i)/norm(A(:,i));
    end
    for i = m/2+1:m
        b(i) = -1;
        A(:,i) = cov_mat*randn(p,1) - mean_vec;
        A(:,i) = A(:,i)/norm(A(:,i));
    end
    for j1 = idx2
        for k1 = idx3
            %% Initialization
            mu1 = 0.01;
            mu2 = 0.01; % strongly convex term
            B = spdiags(b,0,m,m)*A'; % B is a m by p matrix
            B_norm = norm(B);
            e = ones(m,1);
            %% parameter for ADMM
            param.C = @(z)B*z;
            param.CT = @(y)B'*y;
            param.Q = @(z) B_norm^2*z-B'*(B*z);
            param.b = e;
            if j1 == 1
                param.acc = 'Tra'; % Tra, XYY, Ada, Kim, Ba
            elseif j1 == 2
                param.acc = 'Ada';
            elseif j1 == 3
                param.acc = 'Ba';
            end
            fprintf('\n ************************************************\n');
            fprintf('\n test: ADMM %s, m = %2d, p = %2d, s = %2d, beta = %3.2e',param.acc,m,p,s,10^k1);
            param.lam0 = zeros(m,1);
            param.z0 = zeros(p,1);
            param.y0 = e;
%             param.beta = 1/(2*B_norm^2); % 0.15 0.6
            param.beta = 10^k1;
            param.betamin = 1e-6;
            param.tau = 1.5;
            param.sig = mu2;
            param.Cnorm = B_norm;
            param.Maxiter = 10000;
            param.Maxtime = 100;
            param.tol = 1e-5;
            param.verbose = 0;
            param.restart = 0; % restart frequency, 0: no restart.
            %% operator for elastic SVM
            Update_f = @(z,lam,beta)SVM_f(B,z,lam,beta);
            Update_g = @(y,z,lam,beta)SVM_g(mu1,mu2,B_norm,B,y,z,lam,beta);
            KT_resp = @(y,z)SVM_resp(B,y,z);
            KT_resd = @(y,z,lam)SVM_resd(mu1,mu2,B,y,z,lam);
            %% ADMM
            if useADMM == 1
                [runhist,Time] = ADMM_Solver(Update_f,Update_g,KT_resp,KT_resd,param);
                iter = runhist.iter;
                Resp = runhist.Resp;
                Resd = runhist.Resd;
                resp = Resp(end);
                resd = Resd(end);
                fprintf('\n iter = %2d, resp = %6.7e, resd = %6.7e',iter,resp,resd);
                if j1 == 1
                    SVM_tra_hist = [SVM_tra_hist,runhist];
                elseif j1 == 2
                    SVM_ada_hist = [SVM_ada_hist,runhist];
                elseif j1 == 3
                    SVM_ba_hist = [SVM_ba_hist,runhist];
                end
                   
            end
        end
    end
end
%% plot results
S_ada = SVM_ada_hist;
S_tra = SVM_tra_hist;
S_ba = SVM_ba_hist;
S_ada_iter = [S_ada.iter];
S_tra_iter = [S_tra.iter];
S_ba_iter = [S_ba.iter];
Beta = 10.^(idx3);
l = length(S_ada_iter)/3;
for i = 1:3
    subplot(1,3,i)
    loglog(Beta,S_ada_iter((i-1)*l+1:i*l),'g-','linewidth',1);
    hold on
    loglog(Beta,S_tra_iter((i-1)*l+1:i*l),'k--','linewidth',1);
    loglog(Beta,S_ba_iter((i-1)*l+1:i*l),'r+','linewidth',1);
    legend('IADMM','ADMM','Heu-ADMM');
    title(['SVM: p=', num2str(P(i)),',m=', num2str(M(i)),',s=',num2str(S(i))]);
    ylim([10,10^4.2]);
    set(gca,'YTick',[10,10^2,10^3,10^4]);
    set(gca,'YTicklabel',{'10','10^2','10^3','10^4'});
    set(gca,'fontsize',12);
    xlabel('Initial penalty','fontsize',12);
    ylabel('Iterations','fontsize',12);
end
save('SVM_result.mat','SVM_tra_hist','SVM_ada_hist','SVM_ba_hist');






