Authors: Tianyun Tang and Kim-Chuan Toh


A MATLAB software for partial proximal point method with subproblem solved by adaptive ADMM

Problem:     min  f(x)+g(y)

             s.t. Ax+By=b

Subproblem:  min  f(x)+g(y)+sigma*||y-y_k||^2/2
             s.t. Ax+By=b  


Real datasets: 

1, Chang, C.C., Lin, C.J:  a library for support vector machines. ACM Trans. Intell. Syst. Tachnol. (TIST) 2(3), 1-27 (2011)

2, Mars, I., Meszaros, C.: A repository of convex quadratic programmming problems. Optim. Methods Softw. 11(1-4), 671-681 (1999)



Citations: 

1, Tianyun Tang and Kim-Chuan Toh, Self-adaptive ADMM for semi-strongly convex problems, mathematical Programming Computation, in print, 2023. 

The proximal mapping in the Rank LASSO problem comes from the following paper.

2, Meixia Lin, Defeng Sun and Kim-Chuan Toh, Efficient sparse semismooth newton methods for the clustered lasso problem SIAM J. Optim. 29(3), 2026-2052 (2019).







