%% convex quadratic programming
% min delta_[a,b](y)+1/2z'Qz+q'z
%  s.t . y-Bz=0.
%% this problem is to verify the theory
clear all;
close all;
addpath('Solver');
addpath('Operator/QP/')
rand('seed',20200420); randn('seed',20200420);
useIADMM = 1;
useXYYADMM = 0;
useKimADMM = 0; 
useTD = 0;
%% generated data
n = 2000;
m = 2000;
sigma = 0.1;
m1 = ceil(m/2)+1;
R = randn(m,m1);
R = R/sqrt(m1);
q = randn(m,1); 
B = randn(n,m); 
B = B/sqrt(n); % B is a n by m full row rank matrix
Q = R*R'+sigma*eye(m); % Q is a m by m positive definite matrix with sigma = 1;
z = randn(m,1);
a = B*z-rand(n,1);
b = B*z+rand(n,1); % box constraint
B_norm = norm(B);
BB = B'*B;
%% parameter for ADMM
param.C = @(z)-B*z;
param.CT = @(y)-B'*y;
param.Q = @(z) 0;
param.b = 0;
param.acc = 'Ada'; % Tra, XYY, Ada, Kim
param.lam0 = zeros(n,1); 
param.z0 = zeros(m,1);
param.y0 = zeros(n,1);
param.beta = 1/(2*B_norm^2);
param.betamin = 1e-4;
param.tau = 1.5;
param.sig = sigma;
param.Cnorm = B_norm;
param.Maxiter = 500;
param.Maxtime = 300;
param.tol = 1e-18;
param.verbose = 1;
param.restart = 0; % restart frequency, 0: no restart.
%% operator for elastic SVM
Update_f = @(z,lam,beta)QP_f(a,b,B,z,lam,beta);
Update_g = @(y,z,lam,beta)(Q+beta*BB)\(B'*lam+beta*B'*y-q);
KT_resp = @(y,z)QP_resp(B,y,z);
KT_resd = @(y,z,lam)QP_resd(a,b,B,Q,q,y,z,lam);
%% ADMM ada
if useIADMM == 1
    [runhist_ada,Time] = ADMM_Solver(Update_f,Update_g,KT_resp,KT_resd,param);
    Beta_ada = runhist_ada.Beta;
    Resp_ada = runhist_ada.Resp;
    Resd_ada = runhist_ada.Resd;
end
%% ADMM XYY
if useXYYADMM == 1
    param.acc = 'XYY';
    param.beta = 1/(2*B_norm^2);
    [runhist_xyy,Time] = ADMM_Solver(Update_f,Update_g,KT_resp,KT_resd,param);
    Beta_xyy = runhist_xyy.Beta;
    Resp_xyy = runhist_xyy.Resp;
    Resd_xyy = runhist_xyy.Resd;
end
%% ADMM Kim
if useKimADMM == 1
    param.acc = 'Kim';
    param.beta = 25/(2*B_norm^2);
    [runhist_kim,Time] = ADMM_Solver(Update_f,Update_g,KT_resp,KT_resd,param);
    Beta_kim = runhist_kim.Beta;
    Resp_kim = runhist_kim.Resp;
    Resd_kim = runhist_kim.Resd;
end
%% TD
%% parameter for TD
if useTD == 1
    gamma = 0.75;
    param.gamma = gamma; % gamma\in (0.5,1]
    c = 4;
    param.c = c; % c>2
    Gamma = 2-1/gamma;
    param.beta = c*(c-1)*Gamma*param.sig/((2*c-1)*B_norm^2);
    %% operator for TD
    Prox_f = @(x,beta)a.*(x<a)+b.*(x>b)+x.*(x>=a).*(x<=b);
    I = eye(m);
    Prox_g = @(x,beta)(Q+beta*I)\(beta*x-q);
    [runhist_TD,Time] = TD_Solver(Prox_f,Prox_g,KT_resp,KT_resd,param);
    Beta_TD = runhist_TD.Beta;
    Resp_TD = runhist_TD.Resp;
    Resd_TD = runhist_TD.Resd;
end
%% plot results
lsize = 8;
tsize = 10;
asize = 15;
% fig2 = figure('papersize',[10,30]);
fig2 = figure('Position',[100, 100, 1200,300]);
Ada = runhist_ada;
Kim = runhist_kim;
XYY = runhist_xyy;
TD = runhist_TD;
iter = Ada.iter;
ada_beta = [Ada.Beta{1:iter}];
kim_beta = [Kim.Beta{1:iter}];
xyy_beta = [XYY.Beta{1:iter}];
td_beta = [TD.Beta{1:iter}];
subplot(1,3,1)
semilogy(1:iter,Ada.Resp,'g-','linewidth',1);
hold on
semilogy(1:iter,Ada.Resd,'g--','linewidth',1);
semilogy(1:iter,TD.Resp,'b-','linewidth',1);
semilogy(1:iter,TD.Resd,'b--','linewidth',1);
semilogy(1:iter,Kim.Resp,'k-','linewidth',1);
semilogy(1:iter,Kim.Resd,'k--','linewidth',1);
semilogy(1:iter,XYY.Resp,'r-','linewidth',1);
semilogy(1:iter,XYY.Resd,'r--','linewidth',1);
legend('IADMM-p','IADMM-d','acc1-ADMM-p','acc1-ADMM-d','acc2-ADMM-p',...
    'acc2-ADMM-d','acc3-ADMM-p','acc3-ADMM-d');
set(gca,'fontsize',lsize);
xlabel('Iterations','fontsize',asize);
ylabel('primal and dual infeasibility','fontsize',asize);
title(['QP: \lambda_{min}(H)=',num2str(sigma)],'fontsize',tsize);

subplot(1,3,2)
res_ada = max(Ada.Resd,Ada.Resp);
res_td = max(TD.Resd,TD.Resp);
res_kim = max(Kim.Resd,Kim.Resp);
res_xyy = max(XYY.Resd,XYY.Resp);
bb = ceil(iter/4):iter;
loglog(1:iter,res_ada,'g-','linewidth',1);
hold on
loglog(1:iter,res_td,'b-','linewidth',1);
loglog(1:iter,res_kim,'k-','linewidth',1);
loglog(1:iter,res_xyy,'r-','linewidth',1);
loglog(bb,1./bb,'k--','linewidth',1);
loglog(bb,10^2*(1./bb).^2,'b--','linewidth',1);
legend('IADMM','acc1-ADMM','acc2-ADMM','acc3-ADMM','\Theta(1/n)','\Theta(1/n^{2})');
set(gca,'fontsize',lsize);
xlabel('Iterations','fontsize',asize);
ylabel('KKT-Residue','fontsize',asize);
title(['QP: \lambda_{min}(H)=',num2str(sigma)],'fontsize',tsize);

subplot(1,3,3)
loglog(1:iter,ada_beta,'g-','linewidth',1);
hold on
loglog(1:iter,td_beta,'b-','linewidth',1);
loglog(1:iter,kim_beta,'k-','linewidth',1);
loglog(1:iter,xyy_beta,'r-','linewidth',1);
loglog(bb,bb/10,'r--','linewidth',1);
loglog(bb,bb.^2/100,'b--','linewidth',1);
legend('IADMM','acc1-ADMM','acc2-ADMM','acc3-ADMM','\Theta(n)','\Theta(n^2)');
set(gca,'fontsize',lsize);
xlabel('Iterations','fontsize',asize);
ylabel('penalty parameter','fontsize',asize);
title(['QP: \lambda_{min}(H)=',num2str(sigma)],'fontsize',tsize);
if sigma == 1
    save('QP_result_2000.mat','runhist_ada','runhist_xyy','runhist_kim','runhist_TD');
elseif sigma == 0.5
    save('QP_result_2000_05.mat','runhist_ada','runhist_xyy','runhist_kim','runhist_TD');
elseif sigma == 0.1
    save('QP_result_2000_01.mat','runhist_ada','runhist_xyy','runhist_kim','runhist_TD');
end


