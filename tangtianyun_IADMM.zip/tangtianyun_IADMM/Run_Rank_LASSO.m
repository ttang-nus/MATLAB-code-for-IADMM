%% Rank LASSO
%% min 2*sum_{i<j}|B_ix-c_i-B_jx+c_j|/n(n-1)+k*|x|
%% min 2*sum_{i<j}|y_i-y_j|/n(n-1)+k|z| s.t. y-Bz=-c
close all; 
addpath('Solver'); 
addpath('Operator/TF/');
addpath('datademo/');
useIADMM = 1;
useLADMM = 0;
useADMM = 0;
tol = 1e-5; 
%% Generate data
fname = {'mpg_scale_expanded7','pyrim_scale_expanded5'};
N = [1000,1000,2000,2000,4000,4000];
M = [2000,4000,4000,8000,8000,10000];
datatype = 3; % 1, real; 2, random with different noise 3, random with different size
for k = 1
    rng('default'); 
    if datatype == 1
        useGurobi = 0;
        M = load([fname{k},'.mat']);
        B = M.A;
        c = M.b;
        [n,m] = size(B);
        if (n*m)/nnz(B)<5
            B = full(B);
        end
%         if issparse(B)
%             cd = sqrt(cond(full(B*B')));
%         else
%             d1 = svds(B,1,'largest');
%             d2 = svds(B,1,'smallest');
%             cd = d1/d2;
%         end
%         fprintf('\n %s & %3.2e',fname{k},cd);
    elseif datatype == 2
        noisetype = k; % 1,N(0,0.25); 2,N(0,1); 3,N(0,2); 4,0.95N(0,1)+0.05N(0,100); 5,sqrt(2)t(4); 6,Cauchy(0,1)
        n = 200; m = 1000;
        Sigma = 0.5*ones(m,m)+0.5*eye(m);
        B = mvnrnd(zeros(m,1),Sigma,n);
        T = 3; x = zeros(m,1); x(1:T) = sqrt(3);
        if noisetype == 1
            noise = 0.25*randn(n,1);
        elseif noisetype == 2
            noise = randn(n,1);
        elseif noisetype == 3
            noise = 2*randn(n,1);
        elseif noisetype == 4
            noise = 0.95*randn(n,1)+5*randn(n,1);
        elseif noisetype == 5
            noise = sqrt(2)*trnd(4,n,1);
        elseif noisetype == 6
            noise = trnd(1,n,1);
        end
        c = B*x+noise;
    else
        useGurobi = 0;
        n = N(k);
        m = M(k);
        Sigma = 0.5*ones(m,m)+0.5*eye(m);
        B = mvnrnd(zeros(m,1),Sigma,n);
        T = 3; x = zeros(m,1); x(1:T) = sqrt(3);
        noise = 0.25*randn(n,1);
        c = B*x+noise;
    end
    [kappa] = gen_kappa(B);
    nc = norm(c);
    BT = B';
    if n > 10000
        BBfun = @(x)B*(BT*x);
        B_norm = eigs(BBfun,n,1,'largestreal');
    elseif issparse(B)
        BB = full(B*B');

        B_norm = sqrt(norm(BB));
    else
        B_norm = norm(B);
    end
    verbose = 1;
    beta = max(100/B_norm^2,1e-6);
    %% IADMM
    if useIADMM
        param.C = @(z)-B*z;
        param.CT = @(lam)-BT*lam;
        param.b = -c;
        param.lam0 = zeros(n,1);
        param.z0 = zeros(m,1);
        param.y0 = zeros(n,1);
        param.sig = 1;
        param.Cnorm = B_norm;
        param.Maxiter = 5000;
        param.Maxtime = 3600;
        param.beta = beta;
        param.tol = tol;
        param.verbose = verbose;
        param.usePPPA = 1;
        Fun = @(y,z)Ffun(y,z,kappa);
        Update_f = @(z,lam,beta,dataf)Update_ffun(z,lam,beta,1,B,c);
        Update_g = @(y,z,lam,beta,z0,sig,datag)Update_gfun(y,z,lam,beta,z0,sig,datag,B,BT,c,kappa);
        KT_resd = @(y,z,lam,CTlam,dataf,datag)TF_resd(y,z,lam,CTlam,kappa);
        [fval,runhist] = IADMM_main(Fun,Update_f,Update_g,KT_resd,param);
        z = runhist.z;
        y = runhist.y;
        lam = runhist.lam;
        iter = runhist.iter;
        ttime = runhist.ttime;
        KTp = runhist.KTp;
        KTd = runhist.KTd;
        fprintf('\n n = %s & PPPA & %3.2e & %3.2e & %2d & %6.7e& %3.2e \\\\',num2str(n),KTp,KTd,...
            iter,fval,ttime);
    end
    %% LADMM
    if useLADMM
        param.C = @(z)-B*z;
        param.CT = @(lam)-BT*lam;
        param.b = -c;
        param.lam0 = zeros(n,1);
        param.z0 = zeros(m,1);
        param.y0 = zeros(n,1);
        param.Maxiter = 500000;
        param.Maxtime = 3600;
        param.beta = beta;
        param.tol = tol;
        param.verbose = verbose;
        Update_f = @(z,lam,beta,dataf)Update_ffun(z,lam,beta,1,B,c);
        Update_g = @(y,z,lam,beta)Update_Lgfun(y,z,lam,beta,B,BT,B_norm,c,kappa);
        KT_resd = @(y,z,lam,CTlam)TF_resd(y,z,lam,CTlam,kappa);
        [fval,runhist] = LADMM_main(Fun,Update_f,Update_g,KT_resd,param);
        iter = runhist.iter;
        ttime = runhist.ttime;
        KTp = runhist.KTp;
        KTd = runhist.KTd;
        fprintf('\n m = %s & LADMM & %3.2e & %3.2e & %2d & %6.7e& %3.2e \\\\',num2str(m),KTp,KTd,...
            iter,fval,ttime);
    end
    %% ADMM
    if useADMM
        BB = B*BT;
        L = chol(B*BT+eye(n),'upper');
        LT = L';
        param.C = @(z)-B*z;
        param.CT = @(lam)-BT*lam;
        param.b = -c;
        param.lam0 = zeros(n,1);
        param.mu0 = zeros(m,1);
        param.z0 = zeros(m,1);
        param.y0 = zeros(n,1);
        param.Cnorm = B_norm;
        param.Maxiter = 500000;
        param.Maxtime = 3600;
        param.beta = beta;
        param.tol = tol;
        param.verbose = verbose;
        Update_f = @(y,z,lam,mu,beta)Update_Affun(y,z,lam,mu,beta,B,BT,L,LT,c);
        Update_g = @(x,lam,mu,beta)Update_Agfun(x,lam,mu,beta,B,c,kappa);
        KT_resd = @(y,z,lam,CTlam)TF_resd(y,z,lam,CTlam,kappa);
        [fval,runhist] = ADMM_main(Fun,Update_f,Update_g,KT_resd,param);
        iter = runhist.iter;
        ttime = runhist.ttime;
        KTp = runhist.KTd;
        KTd = runhist.KTp;
        fprintf('\n $\\kappa$ = %4.2f & ADMM & %3.2e & %3.2e & %2d & %6.7e& %3.2e \\\\',kappa,KTp,KTd,...
            iter,fval,ttime);
    end
end







