function [y] = SVM_f(B,z,lam,beta)
m = size(B,1);
e = ones(m,1);
b = e-B*z-lam/beta;
tau = 1/(m*beta);
y = (b>=tau).*(b-tau)+(b<0).*b;
end

