function [resd] = SVM_resd(mu1,mu2,B,y,z,lam)
m = size(B,1);
e = ones(m,1);
b = y-lam;
tau = 1/m;
p = (b>=tau).*(b-tau)+(b<0).*b;
fed1 = norm(p-y,'fro')/max(norm(y,'fro'),norm(lam,'fro'));
tau = mu1/mu2;
Blam = B'*lam;
b = -Blam/mu2;
p = max(abs(b)-tau,0).*sign(b);
fed2 = norm(p-z,'fro')/max(norm(z,'fro'),norm(Blam,'fro'));
resd = max(fed1,fed2);
end

