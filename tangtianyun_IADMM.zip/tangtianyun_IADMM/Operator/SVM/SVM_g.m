function [zz] = SVM_g(mu1,mu2,B_norm,B,y,z,lam,beta)
m = size(B,1);
e = ones(m,1);
mub = mu2+beta*B_norm^2;
tau = mu1/mub;
btau = beta/mub;
b = btau*B'*(e-y-B*z)+btau*B_norm^2*z-B'*lam/mub;
zz = max(abs(b)-tau,0).*sign(b);
end

