function [resp] = SVM_resp(B,y,z)
m = size(B,1);
e = ones(m,1);
Bz = B*z;
resp = norm(y+Bz-e,'fro')/max([norm(y,'fro'),norm(Bz,'fro'),norm(e,'fro')]);
end

