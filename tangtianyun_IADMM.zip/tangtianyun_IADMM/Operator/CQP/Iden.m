%% identify dense column, apply cholesky decomposition
function [L,LT,p,ip,V,VT] = Iden(A)
[m,n] = size(A);
d = sum(spones(A),1);
idx = find((d>0.2*m)+(d>200));
if length(idx)>m/2
    idx = [];
end
V = A(:,idx);
VT = V';
idxs = setdiff(1:n,idx);
As = A(:,idxs);
Q = As*As';
[L,~,p] = chol(Q,'vector');
LT = L';
ip(p) = 1:m;
end