%% active set identification
function [x,lambda,KTp,KTd,fval] = Acts(Q,c,A,AT,b,lb,ub,x,tolp,tol)
[m,n] = size(A);
%% identify inactive constraints
id = ones(n,1);
id1 = x>ub-tolp;
id(id1) = 0;
id2 = x<lb+tolp;
id(id2) = 0;
idx = find(id);
idx1 = setdiff(1:n,idx)
Ai = A(:,idx); 
Qi = Q(idx,idx); 
ci = c(idx);
y = zeros(n,1);
id1 = find(x>ub-tolp);
y(id1) = ub(id1);
id2 = find(x<lb+tolp);
y(id2) = lb(id2);
bi = b-A*y;
AQA = [Qi,-Ai';-Ai,sparse(m,m)];
xiplam = AQA\[-ci;-bi];
r = length(idx);
xi = xiplam(1:r);
lambda = xiplam(r+1:end);
y(idx) = xi;
y = projlu(y,lb,ub);
KTp = norm(A*y-b)/(1+norm(b));
Qy = Q*y;
fval = y'*Qy/2+c'*y;
KTd = norm(projlu(y-(Qy+c-AT*lambda),lb,ub)-y)/(1+norm(Qy+c));
if max(KTp,KTd)<tol
    fprintf('\n active set');
    x = y;
end
end