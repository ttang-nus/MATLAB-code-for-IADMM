function [y,dataf] = Absolve(y,A,AT,b,dataf)
[m,n] = size(A);
b_Ay = b-A*y;
if ~isfield(dataf,'usemwf')
    Astruc = sum(spones(A));
    denidx = find((Astruc/m>0.5)+(Astruc>=100));
    spidx = setdiff(1:n,denidx);
    if length(denidx)>m/2
        denidx = [];
        spidx = 1:n;
    end
    if isempty(denidx)
        dataf.usemwf = 0;
        Q = A*AT;
        if isdiag(Q)
            dataf.isd = 1;
            q = diag(Q);
            lam = b_Ay./q;
            y = y+AT*lam;
            dataf.q = q;
        elseif nnz(Q)>m^2/10
            dataf.isd = 0;
            Q = full(Q);
            L = chol(Q,'upper');
            LT = L';
            p = 1:m;
            ip = 1:m;
            lam = Ainv(b_Ay,L,LT,p,ip);
            y = y+AT*lam;
            dataf.L = L;
            dataf.LT = LT;
            dataf.p = p;
            dataf.ip = ip;
        else
            dataf.isd = 0;
            [L,~,p] = chol(Q,'vector');
            LT = L';
            ip(p) = 1:m;
            lam = Ainv(b_Ay,L,LT,p,ip);
            y = y+AT*lam;
            dataf.L = L;
            dataf.LT = LT;
            dataf.p = p;
            dataf.ip = ip;
        end
    else
        dataf.usemwf = 1;
        V = A(:,denidx);
        VT = V';
        Asp = A(:,spidx);
        Q = Asp*Asp';
        %% chol Q+VVT
        r = size(V,2);
        [L,~,p] = chol(Q,'vector');
        LT = L';
        ip(p) = 1:m;
        IVTQiV = speye(r)+VT*Ainv(V,L,LT,p,ip);
        IVVinv = inv(IVTQiV);
        Qib = Ainv(b_Ay,L,LT,p,ip);
        VTQib = VT*Qib;
        IVVb = IVTQiV\VTQib;
        lam = Qib-Ainv(V*IVVb,L,LT,p,ip);
        y = y+AT*lam;
        dataf.IVVinv = IVVinv;
        dataf.L = L;
        dataf.LT = LT;
        dataf.p = p;
        dataf.ip = ip;
        dataf.V = V;
        dataf.VT = VT;
    end
else
    if dataf.usemwf == 1
        IVVinv = dataf.IVVinv;
        L = dataf.L;
        LT = dataf.LT;
        p = dataf.p;
        ip = dataf.ip;
        V = dataf.V;
        VT = dataf.VT;
        Qib = Ainv(b_Ay,L,LT,p,ip);
        VTQib = VT*Qib;
        IVVb = IVVinv*VTQib;
        lam = Qib-Ainv(V*IVVb,L,LT,p,ip);
        y = y+AT*lam;
    else
        if dataf.isd == 1
            q = dataf.q;
            lam = b_Ay./q;
            y = y+AT*lam;
        else
            L = dataf.L;
            LT = dataf.LT;
            p = dataf.p;
            ip = dataf.ip;
            lam = Ainv(b_Ay,L,LT,p,ip);
            y = y+AT*lam;
        end
    end
end
dataf.lam = lam;
end

function Mx = Ainv(x,L,LT,p,ip)
Mx = L\(LT\x(p,:));
Mx = Mx(ip,:);
end