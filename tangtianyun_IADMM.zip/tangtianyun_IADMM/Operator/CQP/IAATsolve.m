%% solve linear system (sig*I+VVT)\b
function [x] = IAATsolve(sig,V,VT,b)
[m,n] = size(V);
if n<m %% useMWF
    Qib = b/sig;
    VTQib = VT*Qib;
    IVVb = LinvI(VT/sqrt(sig),V/sqrt(sig),VTQib);
    x = Qib-(V*IVVb)/sig;
else
    x = (LinvI(V/sqrt(sig),VT/sqrt(sig),b))/sig;
end
end

function x = LinvI(V,VT,b) 
[m,n] = size(V);
%% identify dense column
d = sum(spones(V),1);
idx = find((d>0.2*m)+(d>200));
if (~isempty(idx))&&(length(idx)<m/10)
    Vd = V(:,idx);
    r = length(idx);
    VdT = Vd';
    Vs = V(:,setdiff(1:n,idx));
    Q = speye(m)+Vs*Vs';
    QibVd = Q\[b,Vd]; 
    Qib = QibVd(:,1);
    QiVd = QibVd(:,2:end);
    VTQib = VdT*Qib;
    IVVb = Vd*((speye(r)+VdT*QiVd)\VTQib);
    x = Qib-Q\IVVb;
else
    Q = speye(m)+V*VT;
    x = Q\b;
end
end