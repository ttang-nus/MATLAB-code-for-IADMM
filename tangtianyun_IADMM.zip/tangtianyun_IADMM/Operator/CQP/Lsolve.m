%% solve linear system by direct solver
function [x] = Lsolve(M,b)
L = M.L;
LT = M.LT;
if isfield(M,'p')
    p = M.p;
    ip = M.ip;
    x = L\(LT\b(p,:));
    x = x(ip,:);
else
    x = L\(LT\b);
end
end