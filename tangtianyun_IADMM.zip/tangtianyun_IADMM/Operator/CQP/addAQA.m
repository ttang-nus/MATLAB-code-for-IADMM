%% store the cholesky decomposition of Q+I/beta
function [cholAQA,BETA] = addAQA(Q,A,AT,beta,cholAQA,BETA)
if isempty(find(BETA==beta,1))
    n = size(Q,1);
    i = min(find(BETA==0, 1 ));
    if isempty(i)
        [~,i] = max(max(BETA/beta,beta./BETA));
    end
    BETA(i) = beta;
    if isdiag(Q)
        q = diag(Q);
        qb = q+beta;
        M.qb = qb;
        Aqb = A./sqrt(qb)';
        [L,LT,p,ip,V,VT] = Iden(Aqb);
        M.L = L;
        M.LT = LT;
        M.p = p;
        M.ip = ip;
        M.V = V;
        M.VT = VT;
        if ~isempty(V)
            r = size(V,2);
            M.VTQiV = eye(r)+full(VT*Lsolve(M,V));
        end
        cholAQA{i} = M;
    elseif issparse(Q)
        Qb = Q+beta*speye(n);
        M.Qb = Qb;
        [QL,~,Qp] = chol(Qb,'vector');
        QLT = QL';
        Qip(Qp) = 1:n;
        M.QL = QL;
        M.Qp = Qp;
        M.QLT = QLT;
        M.Qip = Qip;
        AQb = (QLT\AT(Qp,:))';
        [L,LT,p,ip,V,VT] = Iden(AQb);
        M.L = L;
        M.LT = LT;
        M.p = p;
        M.ip = ip;
        M.V = V;
        M.VT = VT;
        if ~isempty(V)
            r = size(V,2);
            M.VTQiV = eye(r)+full(VT*Lsolve(M,V));
        end
        cholAQA{i} = M;
    else
        Qb = Q+beta*eye(n);
        QL = chol(Qb,'upper');
        QLT = QL';
        M.Qb = Qb;
        M.QL = QL;
        M.QLT = QLT;
        AQb = full(QLT\AT)';
        AQA = AQb*AQb';
        L = chol(AQA,'upper');
        LT = L';
        M.L = L;
        M.LT = LT;
        cholAQA{i} = M;
    end
end
end


