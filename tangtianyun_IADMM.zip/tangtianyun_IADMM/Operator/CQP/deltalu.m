%% delta^*_[lb,ub](s)
function fval = deltalu(s,lb,ub)
fval = 0;
idx1 = find(s>0);
if ~isempty(idx1)
    fval = fval+ub(idx1)'*s(idx1);
end
idx2 = find(s<0);
if ~isempty(idx2)
    fval = fval+lb(idx2)'*s(idx2);
end
end