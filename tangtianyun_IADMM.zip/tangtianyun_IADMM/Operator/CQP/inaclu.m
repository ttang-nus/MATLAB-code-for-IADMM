%% find inactive constraints [lb, ub]
function id = inaclu(x,lb,ub)
n = length(x);
id = ones(n,1);
id1 = x>=ub-1e-10;
id(id1) = 0;
id2 = x<=lb+1e-10;
id(id2) = 0;
end