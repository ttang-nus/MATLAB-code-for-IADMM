%% projection on to [lb,ub]
function [y] = projlu(x,lb,ub)
y = x;
id1 = find(x>ub);
y(id1) = ub(id1);
id2 = find(x<lb);
y(id2) = lb(id2);
end