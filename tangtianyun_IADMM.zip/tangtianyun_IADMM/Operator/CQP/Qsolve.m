%% solve min zTQz/2+beta||z-zh||^2/2: l<=z<=u
function [z,BID,cholQbe,datag] = Qsolve(Q,QL,QLT,zh,beta,lb,ub,BID,cholQbe,datag)
n = size(Q,1);
if isdiag(Q) == 1 
    q = diag(Q);
    zh = beta*zh./(beta+q);
    z = projlu(zh,lb,ub);
    lam = zeros(n,1);
else %% SSN
    if isfield(datag,'lam')
        lam = datag.lam;
    else
        lam = zeros(n,1);
    end
    zp = zh+QL(lam)/beta;
    z = projlu(zp,lb,ub);
    id = inaclu(zp,lb,ub);
    bb = -QLT(z)-lam;
    res = norm(bb)/(1+norm(zh));
    while res > 1e-10
        idx = find(id);
        if isempty(idx)
            lamp = bb;
            lam = lam+lamp;
            zp = zh+QL(lam)/beta;
            z = projlu(zp,lb,ub);
            id = inaclu(zp,lb,ub);
            bb = -QLT(z)-lam;
            res = norm(bb)/(1+norm(zh));
        else
            [cholQbe,BID] = addQbe(Q,beta,id,cholQbe,BID);
            l = zeros(n,1);
            Lbb = QL(bb);
            ii = find(sum(abs(BID-[beta;id]))==0,1);
            M = cholQbe{ii};
            l(idx) = Lsolve(M,Lbb(idx))*beta;
            lamp = bb-QLT(l)/beta;
            lam = lam+lamp;
            zp = zh+QL(lam)/beta;
            z = projlu(zp,lb,ub);
            id = inaclu(zp,lb,ub);
            bb = -QLT(z)-lam;
            res = norm(bb)/(1+norm(zh));
        end
    end
end
datag.lam = lam;
end