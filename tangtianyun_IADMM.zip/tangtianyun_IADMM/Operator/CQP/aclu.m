%% find active constraints [lb, ub]
function id = aclu(x,lb,ub)
n = length(x);
id = zeros(n,1);
id1 = x>=ub-1e-10;
id(id1) = 1;
id2 = x<=lb+1e-10;
id(id2) = 1;
end