%% solve linear system by MWF
function [x] = Msolve(M,b)
if isfield(M,'p')
    if isfield(M,'VTQiV')
        V = M.V;
        VT = M.VT;
        VTQiV = M.VTQiV;
        Qib = Lsolve(M,b);
        VTQib = VT*Qib;
        IVVb = VTQiV\VTQib;
        x = Qib-Lsolve(M,V*IVVb);
    else
        x = Lsolve(M,b);
    end
else
    x = Lsolve(M,b);
end
end