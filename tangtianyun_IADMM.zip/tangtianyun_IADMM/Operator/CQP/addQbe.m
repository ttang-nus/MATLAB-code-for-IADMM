%% store the cholesky decomposition of Q+beta*I
function [cholQbe,BID] = addQbe(Q,beta,id,cholQbe,BID)
if isempty(find(sum(abs(BID-[beta;id]))==0,1))
    i = min(find(sum(BID)==0,1));
    if isempty(i)
        BETA = BID(1,:);
        [~,i] = max(max(BETA/beta,beta./BETA));
    end
    BID(1,i) = beta;
    BID(2:end,i) = id;
    idx = find(id);
    Qi = Q(idx,idx);
    n = length(idx);
    if issparse(Q)
        Qbe = Qi+beta*speye(n);
        [L,~,p] = chol(Qbe,'vector');
        M.Qbe = Qbe;
        M.L = L;
        M.LT = L';
        M.p = p;
        ip(p) = 1:n;
        M.ip = ip;
        cholQbe{i} = M;
    else
        Qbe = Qi+beta*eye(n);
        L = chol(Qbe,'upper');
        M.Qbe = Qbe;
        M.L = L;
        M.LT = L';
        cholQbe{i} = M;
    end
end
end