%% Update x in ADMM
function [x] = Update_Affun(y,z,lam,mu,beta,B,BT,L,LT,c)
xx = (-BT*(lam-beta*y-beta*c)+mu+beta*z)/beta;
x = xx-BT*(L\(LT\(B*xx)));
end