%% KKT dual residue
function dfeas = TF_resd(y,z,lam,CTlam,kappa)
ypl = y+lam;
n = length(y);
rho = 2/(n*(n-1));
pf = prox_sClu(ypl,rho) ;
KTd1 = norm(pf-y)/max(norm(y),norm(lam));
zpCTl = z+CTlam;
KTd2 = norm(max(abs(zpCTl)-kappa,0).*sign(zpCTl)-z)/max(norm(z),norm(CTlam));
dfeas = max(KTd1,KTd2);
end