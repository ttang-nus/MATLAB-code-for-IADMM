%% Update y and z in ADMM
function [y,z] = Update_Agfun(x,lam,mu,beta,B,c,kappa)
yy = B*x-c+lam/beta;
n = length(yy);
p = 2/(beta*n*(n-1));
y = prox_sClu(yy,p); 
zz = x-mu/beta;
z = max(abs(zz)-kappa/beta,0).*sign(zz);
end