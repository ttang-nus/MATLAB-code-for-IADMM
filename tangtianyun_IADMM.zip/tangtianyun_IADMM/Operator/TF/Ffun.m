%% objective function value
function fval = Ffun(y,z,kappa)
y = sort(y,'ascend');
n = length(y);
l = 2*(1:n)-(n+1);
fval = 2*l*y/(n*(n-1))+kappa*norm(z,1);
end