%% generate regularization parameter for rank LASSO problem
function [kappa] = gen_kappa(B)
rng('default');
n = size(B,1);
l = 1000;
a = zeros(l,1);
for i = 1:l
    xi = 2*randperm(n)-(n+1);
    a(i) = 2*max(abs(xi*B))/(n*(n-1));
end
a = sort(a,'ascend');
kappa = 1.1*a(round(l*0.9));
end