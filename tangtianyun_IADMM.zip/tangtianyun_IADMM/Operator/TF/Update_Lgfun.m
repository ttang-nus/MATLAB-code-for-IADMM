%% Update z in linearized ADMM
function [z] = Update_Lgfun(y,z,lam,beta,B,BT,Bnorm,c,kappa)
b1 = BT*(-lam+beta*(y+c)-beta*B*z);
b2 = z+b1/(beta*Bnorm^2);
rho = kappa/(beta*Bnorm^2);
z = max(abs(b2)-rho,0).*sign(b2);
end