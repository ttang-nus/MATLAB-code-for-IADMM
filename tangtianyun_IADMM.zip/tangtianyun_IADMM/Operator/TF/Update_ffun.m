%% Update y in IADMM
function [pf,dataf] = Update_ffun(z,lam,beta,dataf,B,c)
yy = B*z+lam/beta-c;
n = size(B,1);
p = 2/(beta*n*(n-1));
pf = prox_sClu(yy,p); 
end