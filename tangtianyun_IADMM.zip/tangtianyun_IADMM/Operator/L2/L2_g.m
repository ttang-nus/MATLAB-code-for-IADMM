function [zz] = L2_g(mu1,mu2,B_norm,B,c,y,z,lam,beta) 
mub = mu2+beta*B_norm^2; 
b = B'*(lam+beta*(y+c-B*z))+beta*B_norm^2*z; 
b = b/mub; 
tau = mu1/mub; 
zz = max(abs(b)-tau,0).*sign(b); 
end 
 
