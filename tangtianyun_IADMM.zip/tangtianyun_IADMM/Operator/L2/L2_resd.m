function [resd] = L2_resd(mu1,mu2,B,y,z,lam)
n = size(B,1);
b = y-lam;
b_norm = norm(b,'fro');
if b_norm<=1
    py = zeros(n,1);
else
    y_norm = b_norm-1;
    py = b/(1/y_norm+1);
end
fed1 = norm(py-y,'fro')/max(norm(y,'fro'),norm(lam,'fro'));
tau = mu1/mu2;
Blam = B'*lam;
b = Blam/mu2;
pz = max(abs(b)-tau,0).*sign(b);
fed2 = norm(pz-z,'fro')/max(norm(z,'fro'),norm(Blam,'fro'));
resd = max(fed1,fed2);
end

