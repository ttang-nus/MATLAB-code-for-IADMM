function [y] = L2_f(B,c,z,lam,beta)
n = size(B,1);
b = B*z-c-lam/beta;
b_norm = norm(b,'fro');
if b_norm <= 1/beta
    y = zeros(n,1);
else
    y_norm = b_norm-1/beta;
    y = (beta*b)/(1/y_norm+beta);
end

