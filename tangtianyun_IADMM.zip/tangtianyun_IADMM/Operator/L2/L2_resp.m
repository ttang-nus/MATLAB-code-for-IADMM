function [resp] = L2_resp(c,B,y,z)
Bz = B*z;
resp = norm(y-Bz+c,'fro')/max([norm(y,'fro'),norm(Bz,'fro'),norm(c,'fro')]);
end

