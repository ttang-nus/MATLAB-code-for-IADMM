function [resd] = QP_resd(a,b,B,Q,q,y,z,lam)
bb = y-lam;
n = length(a);
py = zeros(n,1);
idx1 = find(bb<a);
idx2 = find(bb>b);
idx3 = find((bb<=b).*(bb>=a));
py(idx1) = a(idx1);
py(idx2) = b(idx2);
py(idx3) = bb(idx3);
fed1 = norm(py-y,'fro')/max(norm(y,'fro'),norm(lam,'fro'));
Qz = Q*z;
Blam = B'*lam;
fed2 = norm(Qz+q-Blam,'fro')/max([norm(Qz,'fro'),norm(q,'fro'),norm(Blam,'fro')]);
resd = max(fed1,fed2);
end

