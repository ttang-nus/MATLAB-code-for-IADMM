function [y] = QP_f(a,b,B,z,lam,beta)
bb = B*z-lam/beta;
y = a.*(bb<=a)+b.*(bb>=b)+bb.*(bb>a).*(bb<b);
end

