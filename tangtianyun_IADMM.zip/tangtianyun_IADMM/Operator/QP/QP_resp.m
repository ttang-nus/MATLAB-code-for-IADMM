function [resp] = QP_resp(B,y,z)
Bz = B*z;
resp = norm(y-Bz,'fro')/max(norm(y,'fro'),norm(Bz,'fro'));
end

